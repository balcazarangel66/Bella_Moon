// =======================================================
// Archivo: productData.js
// Propósito: Contener todos los datos de los productos centralizados.
// =======================================================

const productData = {
// =======================================================
//Productos de exibicion para el catalogo principal//
 // *** Jerseys ***
                // *** PRODUCTO Jersey-1 ***
                'Jersey-1': {
                    image: 'Imagenes/Jersey.jpg', 
                    categoryName: 'jerseys', 
                    categoryLink: 'Jersey.html', 
                },

                    // *** Playeras ***
                    'Playera-1': {
                    image: 'Imagenes/Camisa1.jpg', 
                    categoryName: 'playeras',
                    categoryLink: '', // Usamos el link que tenías, si es otra página, cámbialo aquí
                },

                    // *** Pijamas ***
                // *** PRODUCTO Pijama-1 ***
                    'Pijama-1': {
                    image: 'Imagenes/Pijama.jpg', 
                    categoryName: 'pijamas',
                    categoryLink: '', // Usamos el link que tenías, si es otra página, cámbialo aquí
                },

                   // *** Jeans ***
                // *** PRODUCTO Pijama-1 ***
                    'Jeans-1': {
                    image: 'Imagenes/Jeans.jpg', 
                    categoryName: 'jeans',
                    categoryLink: '', // Usamos el link que tenías, si es otra página, cámbialo aquí
                },

                     // *** Suters ***
                    'Sueter-1': {
                    image: 'Imagenes/Sueter.jpg', 
                    categoryName: 'sueters',
                    categoryLink: '', // Usamos el link que tenías, si es otra página, cámbialo aquí
                },

                      // *** Vestidos ***
                // *** PRODUCTO Vestido-1 ***
                    'Vestido-1': {
                    image: 'Imagenes/Vestido.jpg', 
                    categoryName: 'vestidos',
                    categoryLink: '', // Usamos el link que tenías, si es otra página, cámbialo aquí
                },

                 'Interior-1': {
                    image: 'Imagenes/Interior1.jpg', 
                    categoryName: 'Ropa Interior',
                    categoryLink: '', // Usamos el link que tenías, si es otra página, cámbialo aquí
                },
}































    