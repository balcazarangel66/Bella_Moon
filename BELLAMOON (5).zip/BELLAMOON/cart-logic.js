// --- FUNCIÓN PARA LIMPIAR Y CONVERTIR PRECIO A NÚMERO ---
const parsePrice = (priceString) => {
    // Elimina 'MXN', '$', comas, y espacios, y lo convierte a float
    const cleaned = priceString.replace('MXN', '').replace('$', '').replace(',', '').trim();
    return parseFloat(cleaned);
};

// --- FUNCIÓN PARA GUARDAR EL PRODUCTO INDIVIDUAL EN LOCAL STORAGE ---
// Nueva función para compra rápida
const saveIndividualProduct = (productId, productData1) => {
    // Obtenemos la información completa del producto
    const productInfo = productData1[productId];
    if (productInfo) {
        // Creamos un array con solo ese producto (simulando un "carrito" de 1 item)
        const singleItemForCheckout = [{ 
            id: productId, 
            quantity: 1, 
            // Usamos el numPrice, o lo parseamos si solo tenemos el string
            price: productInfo.numPrice || parsePrice(productInfo.price), 
            title: productInfo.title,
            image: productInfo.image
        }];
        
        // Guardamos el item en una clave diferente a la del carrito
        localStorage.setItem('bellaMoonIndividualBuy', JSON.stringify(singleItemForCheckout));
        return true;
    }
    return false;
};

document.addEventListener('DOMContentLoaded', () => {
    const categoryItems = document.querySelectorAll('.category-item');
    const categoryItemWrappers = document.querySelectorAll('.category-item-wrapper');
    const searchInput = document.getElementById('search-input');
    const mainProductImage = document.getElementById('main-product-image');
    const productPrice = document.getElementById('product-price');
    const productDelivery = document.getElementById('product-delivery');
    const productReturn = document.getElementById('product-return');
    
    // Elementos del carrito
    const buyNowLink = document.getElementById('buy-now-link');
    const addToCartBtn = document.getElementById('add-to-cart-btn');
    const cartCount = document.getElementById('cart-count');
    const cartList = document.getElementById('cart-list');
    const emptyCartMessage = document.getElementById('empty-cart-message');
    const cartSubtotal = document.getElementById('cart-subtotal');
    const checkoutBtn = document.getElementById('checkout-btn');
    
    // Inicializa el carrito leyendo el Local Storage.
    let cart = JSON.parse(localStorage.getItem('bellaMoonCart')) || []; 
    
    // --- FUNCIÓN PARA GUARDAR EL CARRITO EN LOCAL STORAGE ---
    const saveCart = () => {
        localStorage.setItem('bellaMoonCart', JSON.stringify(cart));
    };

    // --- FUNCIÓN PARA REMOVER UN PRODUCTO DEL CARRITO ---
    const removeItemFromCart = (productId) => {
        const itemIndex = cart.findIndex(item => item.id === productId);
        
        if (itemIndex > -1) {
            cart.splice(itemIndex, 1); // Quita el elemento
            saveCart();
            updateCartDisplay();
        }
    };

    // --- FUNCIÓN PARA ACTUALIZAR LA VISTA PREVIA DEL CARRITO Y EL SUBTOTALL ---
    const updateCartDisplay = () => {
        let totalQuantity = 0;
        let subtotal = 0;
        cartList.innerHTML = ''; // Limpia la lista

        // 1. Calcular total de items y subtotal
        cart.forEach(item => {
            totalQuantity += item.quantity;
            // Utiliza la variable global productData1 (asumiendo que está cargada)
            const productInfo = productData1[item.id]; 
            if (productInfo) {
                // Utiliza la propiedad 'numPrice' que debes tener definida en productData1
                subtotal += productInfo.numPrice * item.quantity; 
            }
        });
        
        // 2. Actualizar el contador del ícono
        cartCount.textContent = totalQuantity;
        cartCount.style.display = totalQuantity > 0 ? 'block' : 'none';

        // 3. Mostrar el subtotal
        cartSubtotal.textContent = `$${subtotal.toLocaleString('es-MX', { minimumFractionDigits: 2 })} MXN`;
        
        // 4. Mostrar u ocultar mensaje de carrito vacío y habilitar/deshabilitar botón de checkout
        if (cart.length === 0) {
            emptyCartMessage.style.display = 'block';
            checkoutBtn.disabled = true; 
        } else {
            emptyCartMessage.style.display = 'none';
            checkoutBtn.disabled = false;
            
            // 5. Renderizar los productos en el modal
            cart.forEach(item => {
                const productInfo = productData1[item.id];
                const title = productInfo ? productInfo.title : 'Producto Desconocido';
                const price = productInfo ? productInfo.numPrice * item.quantity : 0;
                const priceDisplay = `$${price.toLocaleString('es-MX', { minimumFractionDigits: 2 })}`;
                
                const itemHtml = `
                    <div class="row cart-item-row">
                        <div class="col-8">
                            <span class="cart-item-title">${title}</span> 
                            <small class="text-muted d-block">Cantidad: ${item.quantity}</small>
                        </div>
                        <div class="col-3 text-end">
                            <span class="cart-item-price">${priceDisplay}</span>
                        </div>
                        <div class="col-1 text-end">
                            <button class="btn btn-remove-item" data-product-id="${item.id}">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                `;
                cartList.insertAdjacentHTML('beforeend', itemHtml);
            });
            
            // 6. Asignar el listener de remover producto
            document.querySelectorAll('.btn-remove-item').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const productIdToRemove = e.currentTarget.dataset.productId;
                    removeItemFromCart(productIdToRemove);
                });
            });
        }
    };

    // --- FUNCIÓN PRINCIPAL PARA ACTUALIZAR LA VISTA PREVIA DEL PRODUCTO SELECCIONADO ---
    const updateProductDisplay = (productKey) => {
        const data = productData1[productKey];
        if (data) {
            // Actualizar la vista previa
            mainProductImage.src = data.image;
            productPrice.textContent = data.price;
            productDelivery.textContent = data.delivery;
            productReturn.textContent = data.return;
            
            // *** Importante: Ya no usamos el href para la redirección, la manejamos con el Event Listener ***
            // buyNowLink.href = data.buyLink || 'Pago.html'; 
            
            // Actualiza el ID en el botón de carrito para saber qué producto agregar
            addToCartBtn.dataset.currentProductId = productKey;  
        }
    };
    
    // --- FUNCIÓN DE FILTRADO POR BÚSQUEDA ---
    const filterCategories = () => {
        const searchTerm = searchInput.value.toLowerCase().trim();
        let firstVisibleProductKey = null;

        categoryItemWrappers.forEach(wrapper => {
            const itemElement = wrapper.querySelector('.category-item');
            const searchTerms = wrapper.dataset.productSearchTerm.toLowerCase();
            const productId = itemElement.dataset.productId;

            if (searchTerms.includes(searchTerm) || searchTerm === '') {
                wrapper.style.display = 'block';
                
                if (firstVisibleProductKey === null) {
                    firstVisibleProductKey = productId; // Guarda el ID del primer producto visible
                    itemElement.classList.add('active'); // Activa el primer elemento visible
                } else {
                    itemElement.classList.remove('active'); // Desactiva los demás
                }
            } else {
                wrapper.style.display = 'none';
                itemElement.classList.remove('active');
            }
        });

        // Carga la vista previa del primer elemento encontrado, o la imagen por defecto.
        if (firstVisibleProductKey) {
            updateProductDisplay(firstVisibleProductKey);
        } else {
            // Si no hay resultados
            mainProductImage.src = 'imagenes/Logo.png';
            productPrice.textContent = 'Sin resultados';
            productDelivery.textContent = '';
            productReturn.textContent = '';
            // buyNowLink.href = '#';
            addToCartBtn.dataset.currentProductId = '';
        }
    };

    // 1. Manejador de clic para cargar la vista previa
    categoryItems.forEach(item => {
        item.addEventListener('click', () => {
            categoryItems.forEach(i => i.classList.remove('active'));
            item.classList.add('active');

            const productId = item.dataset.productId;
            updateProductDisplay(productId);
        });
    });

    // 2. Manejador de entrada para el campo de búsqueda
    searchInput.addEventListener('keyup', filterCategories);

    // 3. Manejador para el botón "Añadir al carrito"
    addToCartBtn.addEventListener('click', () => {
        const productId = addToCartBtn.dataset.currentProductId;
        if (!productId || !productData1[productId]) {
            alert('Por favor, selecciona un producto primero.');
            return;
        }

        const existingItem = cart.find(item => item.id === productId);

        if (existingItem) {
            existingItem.quantity += 1; // Si ya existe, aumenta la cantidad
        } else {
            cart.push({ id: productId, quantity: 1 }); // Si no existe, lo agrega
        }
        
        saveCart(); // Guarda en Local Storage
        updateCartDisplay();
        showPopupNotification(`"${productData1[productId].title}" añadido al carrito Exitosamente.`);
    });
    
    // 4. Manejador para el botón de Pagar (Checkout de Carrito)
    checkoutBtn.addEventListener('click', () => {
        if (cart.length > 0) {
            // Elimina cualquier rastro de compra individual anterior
            localStorage.removeItem('bellaMoonIndividualBuy'); 
            window.location.href = 'Pago.html'; 
        }
    });

    // 5. Manejador para el botón "Comprar Ahora" (Compra Individual/Rápida)
    buyNowLink.addEventListener('click', (e) => {
        // Previene la acción por defecto del enlace (para poder guardar los datos)
        e.preventDefault(); 
        
        const productId = addToCartBtn.dataset.currentProductId;
        if (!productId || !productData1[productId]) {
            alert('Por favor, selecciona un producto para comprar.');
            return;
        }

        // Guarda el producto individual en localStorage
        if(saveIndividualProduct(productId, productData1)) {
            // Redirige a la página de pago y agrega el query param para identificar el tipo de compra
            window.location.href = 'Pago.html?type=individual'; 
        } else {
             alert('Error al preparar la compra individual. Intenta de nuevo.');
        }
    });

    // 6. Manejador para el modal del carrito (asegura que la vista se actualice al abrir)
    document.getElementById('cartModal').addEventListener('show.bs.modal', updateCartDisplay);
    
    // Carga inicial al iniciar la página
    //updateProductDisplay('Jersey-1'); // Carga el primer producto por defecto
    //updateCartDisplay(); // Inicializa el carrito leyendo Local Storage y actualiza el contador

///////////////////////////////////////////////

// Función para determinar el producto por defecto según la URL
function getDefaultProductFromURL() {
    // Obtiene el nombre del archivo de la URL (ej: /Playeras.html)
    const pathname = window.location.pathname;
    
    // Verifica si la URL contiene 'Playeras'
    if (pathname.includes('Playera')) {
        return 'Playera-1'; // Producto específico para Playera.html
    }
    
    // Verifica si la URL contiene 'Jerseys'
    if (pathname.includes('Jersey')) {
        return 'Jersey-1'; // Producto específico para Jersey.html
    }

     // Verifica si la URL contiene 'Pijama'
    if (pathname.includes('Pijama')) {
        return 'Pijama-1'; // Producto específico para Pijama.html
    }

     // Verifica si la URL contiene 'Jeans'
    if (pathname.includes('Jean')) {
        return 'Jeans-1'; // Producto específico para Jeans.html
    }

     // Verifica si la URL contiene 'Sueters'
    if (pathname.includes('Sueter')) {
        return 'Sueter-1'; // Producto específico para Sueter.html
    }

      // Verifica si la URL contiene 'Vestidos'
    if (pathname.includes('Vestido')) {
        return 'Vestido-1'; // Producto específico para Jeans.html
    }

    if (pathname.includes('Interior')) {
        return 'Interior-1'; // Producto específico para Jeans.html
    }

    // Valor de respaldo (default) para cualquier otra página
    return 'Jersey-1'; 
}

// --- Carga inicial al iniciar la página ---

// Carga el producto basado en la URL
const initialProduct = getDefaultProductFromURL();
updateProductDisplay(initialProduct); 

// Inicializa el carrito
updateCartDisplay();




/* Funcion para el mensaje emergente de añadir al carrito*/

// --- FUNCIÓN PARA MOSTRAR ALERTA EMERGENTE CON COLORES PERSONALIZADOS ---
const showPopupNotification = (message) => {
    // Crear el contenedor si no existe
    let popup = document.getElementById('cart-popup-notification');
    if (!popup) {
        popup = document.createElement('div');
        popup.id = 'cart-popup-notification';
        document.body.appendChild(popup);

        // Definir los colores
        const pinkMedium = '#f5d0d6'; // para el fondo
        const pinkStrong = '#eb8f9f'; // para borde y texto destacado

        // Estilos
        Object.assign(popup.style, {
            position: 'fixed',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            backgroundColor: pinkMedium,
            color: pinkStrong,
            padding: '20px 30px',
            borderRadius: '12px',
            fontSize: '1rem',
            zIndex: 9999,
            textAlign: 'center',
            boxShadow: '0 4px 15px rgba(0,0,0,0.3)',
            border: `2px solid ${pinkStrong}`,
            fontWeight: '600',
            opacity: 0,
            transition: 'opacity 0.3s ease, transform 0.3s ease'
        });
    }

    popup.textContent = message;

    // Animación de aparición
    popup.style.opacity = 1;
    popup.style.transform = 'translate(-50%, -50%) scale(1.05)';

    // Volver a tamaño normal después de 0.3s
    setTimeout(() => {
        popup.style.transform = 'translate(-50%, -50%) scale(1)';
    }, 50);

    // Desaparecer después de 1.5 segundos
    setTimeout(() => {
        popup.style.opacity = 0;
    }, 1500);
};


  
});