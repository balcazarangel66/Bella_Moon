const productData1 = {
                'Jersey-1': {
                    image: 'Imagenes/Jersey.jpg',  
                    title: 'Jersey Estilo Villano Holgado', // Añadido para el carrito
                    price: '$162 MXN',
                    numPrice: 162.00, // Precio numérico para cálculos
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'jersey',
                    // Boton para la pagina de pago xd
                },
                    // *** PRODUCTO Jersey-2 ***
                   'Jersey-2': {
                    image: 'Imagenes/Jersey1.jpg',  
                    title: 'Jersey Para Mujer adidas México Wc 2026 Fútbol Ka6060', // Añadido para el carrito
                    price: '$1,999 MXN',
                    numPrice: 1999.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'jersey',
                   // Boton para la pagina de pago xd
                },

                    'Jersey-3': {
                    image: 'Imagenes/Jersey2.jpg',  
                    title: 'Jersey 180 Lean Mujer Moto Bici Enduro Bmx Mx Downhill', // Añadido para el carrito
                    price: '$740 MXN',
                    numPrice: 740.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'jersey',
                    // Boton para la pagina de pago xd
                },

                    'Jersey-4': {
                    image: 'Imagenes/Jersey3.jpg',  
                    title: 'Doxe Jersey Playera Dama Triumph Tiger Motociclismo D0004', // Añadido para el carrito
                    price: '$800 MXN',
                    numPrice: 800.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'jersey',
                    // Boton para la pagina de pago xd
                },

                        'Jersey-5': {
                    image: 'Imagenes/Jersey4.jpg',  
                    title: 'Jersey Para Mujer, Diseño De Árbol De Navidad, Ropa Juvenil', // Añadido para el carrito
                    price: '$300 MXN',
                    numPrice: 300.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'jersey',
                    // Boton para la pagina de pago xd
                },

                        'Jersey-6': {
                    image: 'Imagenes/Jersey5.jpg',  
                    title: 'Blusa Jersey De Cuello Tortuga Tejido Rayas Para Dama', // Añadido para el carrito
                    price: '$200 MXN',
                    numPrice: 200.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'jersey',
                    // Boton para la pagina de pago xd
                },

 ///////////////////////////////////////////////////////////////////////////////////////////

                'Playera-1': {
                    image: 'Imagenes/Camisa1.jpg',  
                    title: 'Camisa Junior H', // Añadido para el carrito
                    price: '$200 MXN',
                    numPrice: 200.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'playeras',
                    // Boton para la pagina de pago xd
                },

                  'Playera-2': {
                    image: 'Imagenes/Camisa2.jpg',  
                    title: 'Playera Camisa Junior H Antisocial Social Club Sadboy', // Añadido para el carrito
                    price: '$400 MXN',
                    numPrice: 400.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'playeras',
                    // Boton para la pagina de pago xd
                },

                  'Playera-3': {
                    image: 'Imagenes/Camisa3.jpg',  
                    title: 'Camisa Blanca Manga Larga A La Moda Para Mujer', // Añadido para el carrito
                    price: '$159 MXN',
                    numPrice: 159.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'playeras',
                    // Boton para la pagina de pago xd
                },

                  'Playera-4': {
                    image: 'Imagenes/Camisa4.jpg',  
                    title: 'Camisa Manga Larga Cuadros Para Mujer', // Añadido para el carrito
                    price: '$210 MXN',
                    numPrice: 210.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'playeras',
                    // Boton para la pagina de pago xd
                },

                 'Playera-5': {
                    image: 'Imagenes/Camisa5.jpg',  
                    title: 'Paquete De 3 Camisetas Sin Mangas De Manga Larga Para Mujer', // Añadido para el carrito
                    price: '$295 MXN',
                    numPrice: 295.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'playeras',
                    // Boton para la pagina de pago xd
                },

///////////////////////////////////////////////////////////////////////////////////////////

                 'Pijama-1': {
                    image: 'Imagenes/Pijama.jpg',  
                    title: 'Pijama de Hello Kitty', // Añadido para el carrito
                    price: '$300 MXN',
                    numPrice: 300.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'pijamas',
                    // Boton para la pagina de pago xd
                },

                  'Pijama-2': {
                    image: 'Imagenes/Pijama1.jpg',  
                    title: 'Pijama Navideña Juvenil Polar', // Añadido para el carrito
                    price: '$190 MXN',
                    numPrice: 190.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'pijamas',
                    // Boton para la pagina de pago xd
                },

                 'Pijama-3': {
                    image: 'Imagenes/Pijama2.jpg',  
                    title: 'Conjunto De Pijama Esponjoso Para Mujer, Cálido Y Esponjoso', // Añadido para el carrito
                    price: '$671 MXN',
                    numPrice: 671.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'pijamas',
                    // Boton para la pagina de pago xd
                },

                 'Pijama-4': {
                    image: 'Imagenes/Pijama3.jpg',  
                    title: 'Pijama De Invierno Con Panda Tierno Abrigada Y Cómoda', // Añadido para el carrito
                    price: '$571 MXN',
                    numPrice: 571.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'pijamas',
                    // Boton para la pagina de pago xd
                },

                  'Pijama-5': {
                    image: 'Imagenes/Pijama4.jpg',  
                    title: 'A Pijama De Mujer Con Estampado De Dibujos Animados, Forro', // Añadido para el carrito
                    price: '$485 MXN',
                    numPrice: 485.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'pijamas',
                    // Boton para la pagina de pago xd
                },

/////////////////////////////////////////////////////////////////////////////////////////////////////


                 'Jeans-1': {
                    image: 'Imagenes/jeans.jpg',  
                    title: 'Jeans Mujer Pantalón De Mezclilla', // Añadido para el carrito
                    price: '$600 MXN',
                    numPrice: 600.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'jeans',
                    // Boton para la pagina de pago xd
                },

                 'Jeans-2': {
                    image: 'Imagenes/jeans1.jpg',  
                    title: 'Pantalon Mujer Pierna Ancha Cintura Alta Seven Jeans Wide', // Añadido para el carrito
                    price: '$510 MXN',
                    numPrice: 510.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'jeans',
                    // Boton para la pagina de pago xd
                },

                  'Jeans-3': {
                    image: 'Imagenes/jeans2.jpg',  
                    title: 'Jeans Mujer Pantalón De Mezclilla Stretch Corte Colombiano', // Añadido para el carrito
                    price: '$295 MXN',
                    numPrice: 295.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'jeans',
                    // Boton para la pagina de pago xd
                },

                    'Jeans-4': {
                    image: 'Imagenes/jeans3.jpg',  
                    title: 'Pantalón De Mezclilla Dama Corte Colombiano Itzi Jeans 550', // Añadido para el carrito
                    price: '$289 MXN',
                    numPrice: 289.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'jeans',
                    // Boton para la pagina de pago xd
                },

                
                    'Jeans-5': {
                    image: 'Imagenes/jeans4.jpg',  
                    title: 'Jeans De Pierna Recta Stretch Unicolor Casual Mujer', // Añadido para el carrito
                    price: '$232 MXN',
                    numPrice: 232.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'jeans',
                    // Boton para la pagina de pago xd
                },


//////////////////////////////////////////////////////////////////////////////////////////////////

                'Sueter-1': {
                    image: 'Imagenes/Sueter.jpg',  
                    title: 'Quiubolee! Sudadera Navideña Patricio Estrella Oficial', // Añadido para el carrito
                    price: '$500 MXN',
                    numPrice: 500.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'sueters',
                    // Boton para la pagina de pago xd
                },

                  'Sueter-2': {
                    image: 'Imagenes/Sueter1.jpg',  
                    title: 'Chamarra Térmica Y Afelpada Con Capucha Para Mujer Abrigo', // Añadido para el carrito
                    price: '$297 MXN',
                    numPrice: 297.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'sueters',
                    // Boton para la pagina de pago xd
                },

                   'Sueter-3': {
                    image: 'Imagenes/Sueter2.jpg',  
                    title: 'Ugly Sweater Navideño, Artistas De México , Jenni Rivera', // Añadido para el carrito
                    price: '$499 MXN',
                    numPrice: 499.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'sueters',
                    // Boton para la pagina de pago xd
                },

                'Sueter-4': {
                    image: 'Imagenes/Sueter3.jpg',  
                    title: 'Chaqueta V Para Mujer Tipo Suéter De Felpa De Talla Grande', // Añadido para el carrito
                    price: '$236 MXN',
                    numPrice: 236.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'sueters',
                    // Boton para la pagina de pago xd
                },

                'Sueter-5': {
                    image: 'Imagenes/Sueter4.jpg',  
                    title: 'Mujer Y2k Aesthetic Angel Printed Sudaderas Con Capucha Suda', // Añadido para el carrito
                    price: '$244 MXN',
                    numPrice: 244.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'sueters',
                    // Boton para la pagina de pago xd
                },

//////////////////////////////////////////////////////////////////////////////////////////////


                  'Vestido-1': {
                    image: 'Imagenes/Vestido1.jpg',  
                    title: 'Vestido Largo Casual Abertura Sexy Maria Bela Modelo Abuya', // Añadido para el carrito
                    price: '$274 MXN',
                    numPrice: 274.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'vestidos',
                    // Boton para la pagina de pago xd
                },

                'Vestido-2': {
                    image: 'Imagenes/Vestido2.jpg',  
                    title: 'Vestido De Mujer Con Estampado De Malla Y Cuello En V', // Añadido para el carrito
                    price: '$590 MXN',
                    numPrice: 590.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'vestidos',
                    // Boton para la pagina de pago xd
                },

                'Vestido-3': {
                    image: 'Imagenes/Vestido3.jpg',  
                    title: 'Vestido De Tirantes Fiesta Escote V Con Estampado De Tul', // Añadido para el carrito
                    price: '$600 MXN',
                    numPrice: 600.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'vestidos',
                    // Boton para la pagina de pago xd
                },
                'Vestido-4': {
                    image: 'Imagenes/Vestido4.jpg',  
                    title: 'Vestido De Tirantes Fiesta Escote V Con Estampado De Tul', // Añadido para el carrito
                    price: '$259 MXN',
                    numPrice: 259.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'vestidos',
                    // Boton para la pagina de pago xd
                },
                'Vestido-5': {
                    image: 'Imagenes/Vestido5.jpg',  
                    title: 'Mono Elegante De Talla Grande De Manga Corta Para Mujer', // Añadido para el carrito
                    price: '$247 MXN',
                    numPrice: 247.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'vestidos',
                    // Boton para la pagina de pago xd
                },
                //////////////////////////////////////////////////////////////////////////////////////////////


                  'Interior-1': {
                    image: 'Imagenes/Interior2.jpg',  
                    title: 'Pack De 4 Tangas Sexy De Cintura Baja Para Mujer', // Añadido para el carrito
                    price: '$96 MXN',
                    numPrice: 96.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'vestidos',
                    // Boton para la pagina de pago xd
                },

                'Interior-2': {
                    image: 'Imagenes/Interior3.jpg',  
                    title: 'Tanga Corte De Encaje De Mujer Sexy Bragas De 5 Piezas', // Añadido para el carrito
                    price: '$128 MXN',
                    numPrice: 128.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'vestidos',
                    // Boton para la pagina de pago xd
                },

                'Interior-3': {
                    image: 'Imagenes/Interior4.jpg',  
                    title: 'Calzones Mujer Lumilace Encaje Sexy Suaves Cómodos Pack De 5', // Añadido para el carrito
                    price: '$208 MXN',
                    numPrice: 208.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'vestidos',
                    // Boton para la pagina de pago xd
                },

                'Interior-4': {
                    image: 'Imagenes/Interior5.jpg',  
                    title: 'Paquete 4 Brassier Sin Varillascomodo Y Moderno Respirable', // Añadido para el carrito
                    price: '$239 MXN',
                    numPrice: 239.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'vestidos',
                    // Boton para la pagina de pago xd
                },

                'Interior-5': {
                    image: 'Imagenes/Interior6.jpg',  
                    title: 'Paquete De 6 Brasieres Con Varilla Comodos Colores Surtidos', // Añadido para el carrito
                    price: '$284 MXN',
                    numPrice: 284.00,
                    delivery: 'Llega mañana',
                    return: 'Devolución gratis',
                    category: 'vestidos',
                    // Boton para la pagina de pago xd
                },
 }
 